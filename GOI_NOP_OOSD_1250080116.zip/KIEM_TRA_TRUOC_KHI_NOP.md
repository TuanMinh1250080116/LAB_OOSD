# Kiểm tra bài LAB tổng hợp – Trần Tuấn Minh

Sinh viên: **Trần Tuấn Minh**, MSSV **1250080116**, lớp **12_ĐH_CNPM2**.

File nộp: **BaoCaoTongHop_LAB0-8_1250080116_TranTuanMinh.docx**.

## Đã kiểm tra ở bản local

- Word có LAB 0–8 đúng thứ tự; LAB 01 gồm bài thư viện và nước giải khát.
- Bản cuối **210 trang**, có mục lục và số trang. Trang bắt đầu của 9 LAB khớp trang thực tế: 4, 8, 36, 76, 96, 113, 133, 155, 170.
- Link repository của Minh nằm ở dòng đầu: https://github.com/TuanMinh1250080116/LAB_OOSD. Link được lấy từ cấu hình origin trên máy, không truy cập remote để xác minh.
- Tác giả và người sửa cuối trong metadata Word đều Trần Tuấn Minh. Đã loại thông tin sinh viên của bài mẫu khỏi bản tổng hợp.
- Có thư mục đúng tên **IMAGES**, gồm **140 file PlantUML và 7 file draw.io** có thể chỉnh sửa. Không dùng PNG/JPG thay cho nguồn.
- 147/147 hình UML, ERD và wireframe trong Word khớp với bộ nguồn/ảnh xuất tương ứng. 140 nguồn PlantUML kiểm tra cú pháp và render thành công; 7 draw.io có cấu trúc mô hình và các tham chiếu hợp lệ. Phần có nguồn nhúng đã được khôi phục từ ảnh Word, không dựng file chỉ để chứa ảnh raster.
- Hình LAB 0 là ảnh thao tác môi trường. Các ảnh ứng dụng có sẵn ở LAB 5/6 được giữ theo tài liệu gốc. Các bản phác thảo giao diện LAB 2 được chuyển sang PlantUML/SALT và ghi là thiết kế, không phải chức năng đã cài đặt.
- LAB 03 và LAB 04 được bổ sung dựa trên bài cùng đề, rồi đối chiếu với script SQL Server và code hiện có của Minh. LAB 08 được bổ sung từ bài cùng đề theo sự cho phép của người yêu cầu.
- Không chạy lại các ứng dụng hoặc SQL. Không chuyển kịch bản dự kiến thành kết quả đã kiểm thử đạt.
- Giữ đủ 168 hình nhúng và toàn bộ nội dung 962 hàng bảng từ các phần nguồn. Word ghép hai bảng liền nhau thành một: bản cuối có 131 bảng; không mất nội dung ô.
- Không còn trang trắng do ngắt trang thừa, không phát hiện chữ vượt khổ trang; hình không sai tỷ lệ hoặc vượt kích thước đặt. File đã mở/cập nhật mục lục bằng Word và kiểm tra định dạng bằng docx-cli.

## Cần chủ repository tự hoàn tất trước khi nộp

1. Tải **toàn bộ IMAGES** lên đúng gốc repository của Minh, giữ các file .puml và .drawio. Không chỉ tải ảnh xuất.
2. Đặt repository **Public** và mở link bằng cửa sổ không đăng nhập. Kiểm tra từng thư mục LAB và file nguồn truy cập được.
3. Nộp đúng Word cuối lên cổng học phần trước **23:59 ngày 01/11/2026**, rồi giữ xác nhận nộp thành công.

Lần làm này chỉ thao tác local: không truy cập remote GitHub, không commit, không push và không thay đổi quyền repository. Chưa thể xác nhận quyền Public, nguồn đã tải lên hoặc đã nộp bài thành công.
